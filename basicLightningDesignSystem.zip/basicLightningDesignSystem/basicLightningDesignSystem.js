import { LightningElement, track, wire } from 'lwc';
import getOpportunities from '@salesforce/apex/basicLightningDesignSystemController.getOpportunities'

const columns = [
    { label: 'Opportunity', fieldName: 'Name' },
    { label: 'Account Name', fieldName: 'Account.Name'},
    { label: 'Close Date', fieldName: 'CloseDate', type: 'date' },
    { label: 'Stage', fieldName: 'StageName', type: 'text' },
    { label: 'Confidence', fieldName: 'Probability', type: 'percentage' },
    { label: 'Amount', fieldName: 'Amount', type: 'currency' },
    { label: 'Contact', fieldName: 'email', type: 'email'},
];
export default class BasicLightningDesignSystem extends LightningElement {

    columns = columns;
    @track data = [];
    @wire(getOpportunities)
    Opportunities ({error, data}) {
        if (error) {
            console.log(error);
            // TODO: Error handling
        } else if (data) {
            console.log('Got Data');
            console.log(data);
            this.data = data;
            // TODO: Data handling
        }
    }
    // async connectedCallback(){
    //     data.push({fieldName:'name', value:'CloudHub'});
    // }
}